package com.devsu.hackerearth.backend.client.model;

import javax.persistence.MappedSuperclass;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@MappedSuperclass
public class Person extends Base {

	private static final long serialVersionUID = 1084224L;

	private String name;
	private String dni;
	private String gender;
	private Integer age;
	private String address;
	private String phone;
}
