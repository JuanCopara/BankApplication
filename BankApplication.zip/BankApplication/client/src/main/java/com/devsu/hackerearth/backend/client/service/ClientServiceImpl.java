package com.devsu.hackerearth.backend.client.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.devsu.hackerearth.backend.client.exception.CustomExceptions;
import com.devsu.hackerearth.backend.client.model.Client;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import com.devsu.hackerearth.backend.client.model.dto.PartialClientDto;
import com.devsu.hackerearth.backend.client.model.mapper.ClientMapper;
import com.devsu.hackerearth.backend.client.repository.ClientRepository;

@Service
public class ClientServiceImpl implements ClientService {

	private final ClientRepository clientRepository;

	public ClientServiceImpl(ClientRepository clientRepository) {
		this.clientRepository = clientRepository;
	}

	@Override
	public List<ClientDto> getAll() {
		// Get all clients

		List<ClientDto> clientDtos = new ArrayList<>();
		this.clientRepository.findAll().stream().forEach(entity -> {
			clientDtos.add(ClientMapper.toClientDto(entity));
		});
		return clientDtos;
	}

	@Override
	public ClientDto getById(Long id) {
		// Get clients by id
		return ClientMapper.toClientDto(this.clientRepository.findById(id)
		.orElseThrow(() -> new CustomExceptions("No se encontraron registros con el ID "+ id )));
	}

	@Override
	public ClientDto create(ClientDto clientDto) {
		// Create client
		return ClientMapper.toClientDto(this.clientRepository.save(ClientMapper.toClient(clientDto)));
	}

	@Override
	public ClientDto update(Long id, ClientDto clientDto) {
		// Update client

		Client client = this.clientRepository.findById(id)
		.orElseThrow(()-> new CustomExceptions("No se encontraron registros con el ID "+ id ));

		ClientMapper.updateClient(client,clientDto);

		return ClientMapper.toClientDto(this.clientRepository.save(client));
	}

	@Override
    public ClientDto partialUpdate(Long id, PartialClientDto partialClientDto) {
        // Partial update account
		Client client = this.clientRepository.findById(id)
		.orElseThrow(()-> new CustomExceptions("No se encontraron registros con el ID "+ id ));

		ClientMapper.partialUpdateClient(client,partialClientDto);
		return  ClientMapper.toClientDto(this.clientRepository.save(client));
    }

	@Override
	public void deleteById(Long id) {
		// Delete client
		this.clientRepository.deleteById(id);
	}
}
