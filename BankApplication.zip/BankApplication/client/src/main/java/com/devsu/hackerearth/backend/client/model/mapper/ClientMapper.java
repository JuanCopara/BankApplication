package com.devsu.hackerearth.backend.client.model.mapper;

import com.devsu.hackerearth.backend.client.model.Client;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import com.devsu.hackerearth.backend.client.model.dto.PartialClientDto;

public class ClientMapper {

    public static ClientDto toClientDto(Client client) {
        return new ClientDto(client.getId(), client.getDni(), client.getName(), client.getPassword(), client.getGender(), client.getAge(), client.getAddress(), client.getPhone(), client.getIsActive());
    }

    public static Client toClient(ClientDto clientDto) {

        Client client = new Client();
        client.setName(clientDto.getName());
        client.setDni(clientDto.getDni());
        client.setGender(clientDto.getGender());
        client.setAge(clientDto.getAge());
        client.setAddress(clientDto.getAddress());
        client.setPhone(clientDto.getPhone());
        client.setPassword(clientDto.getPassword());
        client.setIsActive(clientDto.isActive());

        return client;

    }

    public static Client updateClient(Client clientEntity, ClientDto clientDto) {
        clientEntity.setName(clientDto.getName());
        clientEntity.setDni(clientDto.getDni());
        clientEntity.setGender(clientDto.getGender());
        clientEntity.setAge(clientDto.getAge());
        clientEntity.setAddress(clientDto.getAddress());
        clientEntity.setPhone(clientDto.getPhone());
        clientEntity.setPassword(clientDto.getPassword());
        clientEntity.setIsActive(clientDto.isActive());

        return clientEntity;
    }
    
    public static Client partialUpdateClient(Client clientEntity, PartialClientDto partialClientDto) {

        clientEntity.setIsActive(partialClientDto.isActive());
        return clientEntity;
    }
}
