package com.devsu.hackerearth.backend.client.exception;

public class CustomExceptions extends RuntimeException{

    public CustomExceptions(String message) {
        super(message);
    }
    
}

