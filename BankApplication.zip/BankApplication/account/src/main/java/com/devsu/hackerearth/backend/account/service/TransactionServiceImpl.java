package com.devsu.hackerearth.backend.account.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.devsu.hackerearth.backend.account.exception.CustomExceptions;
import com.devsu.hackerearth.backend.account.model.Transaction;
import com.devsu.hackerearth.backend.account.model.dto.BankStatementDto;
import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;
import com.devsu.hackerearth.backend.account.model.mapper.TransactionMapper;
import com.devsu.hackerearth.backend.account.repository.*;
@Service
public class TransactionServiceImpl implements TransactionService {

	private final TransactionRepository transactionRepository;
    private final AccountRepository accountRepository;

	public TransactionServiceImpl(TransactionRepository transactionRepository, AccountRepository accountRepository) {
		this.transactionRepository = transactionRepository;
        this.accountRepository = accountRepository;
	}

    @Override
    public List<TransactionDto> getAll() {
        // Get all transactions

        List<TransactionDto> transactionDtos = new ArrayList<>();

        this.transactionRepository.findAll().stream().forEach(entity -> {
            transactionDtos.add(TransactionMapper.toTransactionDto(entity));
        });

		return transactionDtos;
    }

    @Override
    public TransactionDto getById(Long id) {
        // Get transactions by id
		return TransactionMapper.toTransactionDto(this.transactionRepository.findById(id)
        .orElseThrow(() -> new CustomExceptions("No se encontraron registros con el ID "+ id )));
    }

    @Override
    public TransactionDto create(TransactionDto transactionDto) {
        // Create transaction
		return TransactionMapper.toTransactionDto(this.transactionRepository.save(TransactionMapper.toTransaction(transactionDto)));
    }

    @Override
    public List<BankStatementDto> getAllByAccountClientIdAndDateBetween(Long clientId, Date dateTransactionStart,
            Date dateTransactionEnd) {
        // Report
        List<BankStatementDto> bankStatementDtos = new ArrayList<>();
        this.accountRepository.findAllByClientId(clientId).stream().forEach(
            account -> {
                bankStatementDtos.add(TransactionMapper.toBankStatementDto(this.transactionRepository.findById(account.getId())
                .orElseThrow(() -> new CustomExceptions("No se encontraron registros con el ID "+ account.getId())),account));
            }
        );
        
        return bankStatementDtos.stream()
        .filter(statement -> statement.getDate().after(dateTransactionStart) && statement.getDate().before(dateTransactionEnd))
        .collect(Collectors.toList());

    }

    @Override
    public TransactionDto getLastByAccountId(Long accountId) {
        // If you need it
		return null;
    }

    @Override
    public TransactionDto updateById(Long id, TransactionDto transactionDto) {

        Transaction transaction = this.transactionRepository.findById(id)
        .orElseThrow(()-> new CustomExceptions("No se encontraron registros con el ID "+ id ));
        TransactionMapper.updateTransaction(transaction, transactionDto);
        return TransactionMapper.toTransactionDto(transaction);
    }
    

    @Override
    public void deleteById(Long id){
        this.transactionRepository.deleteById(id);
    }
}

