package com.devsu.hackerearth.backend.account.model.mapper;

import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.Transaction;
import com.devsu.hackerearth.backend.account.model.dto.BankStatementDto;
import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;

public class TransactionMapper {

    public static TransactionDto toTransactionDto(Transaction transaction) {
        return new TransactionDto(transaction.getId(), transaction.getDate(), transaction.getType(),transaction.getAmount(), transaction.getBalance(), transaction.getAccountId());
    }

    public static Transaction toTransaction(TransactionDto transactionDto) {
        Transaction transaction = new Transaction();
        transaction.setDate(transactionDto.getDate());
        transaction.setType(transactionDto.getType());
        transaction.setAmount(transactionDto.getAmount());
        transaction.setBalance(transactionDto.getBalance());
        transaction.setAccountId(transactionDto.getAccountId());

        return transaction;
    }

    public static Transaction updateTransaction(Transaction transactionEntity, TransactionDto transactionDto) {
        transactionEntity.setDate(transactionDto.getDate());
        transactionEntity.setType(transactionDto.getType());
        transactionEntity.setAmount(transactionDto.getAmount());
        transactionEntity.setBalance(transactionDto.getBalance());
        transactionEntity.setAccountId(transactionDto.getAccountId());
        return transactionEntity;
    }

    public static BankStatementDto toBankStatementDto(Transaction transaction, Account account) {
        return new BankStatementDto
        (transaction.getDate(), account.getClientId().toString(), account.getNumber(), account.getType(), account.getInitialAmount(), account.getIsActive(), transaction.getType(), transaction.getAmount(), transaction.getBalance());

    }
    
}
