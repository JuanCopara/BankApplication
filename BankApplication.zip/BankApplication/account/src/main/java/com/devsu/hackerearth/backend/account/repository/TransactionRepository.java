package com.devsu.hackerearth.backend.account.repository;

import java.sql.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.devsu.hackerearth.backend.account.model.Transaction;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Long> {
    
    @Query("FROM Transaction t WHERE t.accountId in ?1 and t.date between ?2 and ?3")
    List<Transaction> getAllByAccountIdsAndDateBetween(List<Long> clientId, Date dateTransactionStart,
    Date dateTransactionEnd);

    @Query("FROM Transaction t WHERE t.accountId = ?1")
    List<Transaction> getByAccountId(Long clientId);
}
