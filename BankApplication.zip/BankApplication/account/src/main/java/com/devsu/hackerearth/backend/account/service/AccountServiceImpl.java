package com.devsu.hackerearth.backend.account.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.devsu.hackerearth.backend.account.exception.CustomExceptions;
import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.dto.AccountDto;
import com.devsu.hackerearth.backend.account.model.dto.PartialAccountDto;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;
import com.devsu.hackerearth.backend.account.model.mapper.*;

@Service
public class AccountServiceImpl implements AccountService {

	private final AccountRepository accountRepository;

	public AccountServiceImpl(AccountRepository accountRepository) {
		this.accountRepository = accountRepository;
	}

    @Override
    public List<AccountDto> getAll() {
        // Get all accounts
        List<AccountDto> accounts = new ArrayList<>();
		this.accountRepository.findAll().stream().forEach(entity -> {
            accounts.add(AccountMapper.toAccountDto(entity));
        });

        return accounts;

    }

    @Override
    public AccountDto getById(Long id) {
        // Get accounts by id
		return AccountMapper.toAccountDto(this.accountRepository.findById(id)
        .orElseThrow(()-> new CustomExceptions("No se encontraron registros con el ID "+ id )));
        
    }

    @Override
    public AccountDto create(AccountDto accountDto) {
        // Create account
        return AccountMapper.toAccountDto(this.accountRepository.save(AccountMapper.toAccount(accountDto)));
    }

    @Override
    public AccountDto update(Long id, AccountDto accountDto) {
        // Update account

        Account account = this.accountRepository.findById(id)
        .orElseThrow(()-> new CustomExceptions("No se encontraron registros con el ID "+ id ));
        AccountMapper.updateAccount(account,accountDto);
		return AccountMapper.toAccountDto(this.accountRepository.save(account));
    }

    @Override
    public AccountDto partialUpdate(Long id, PartialAccountDto partialAccountDto) {
        // Partial update account
        Account account = this.accountRepository.findById(id)
        .orElseThrow(()-> new CustomExceptions("No se encontraron registros con el ID "+ id ));
        AccountMapper.partialUpdateAccount(account,partialAccountDto);
		return AccountMapper.toAccountDto(this.accountRepository.save(account));
    }

    @Override
    public void deleteById(Long id) {
        // Delete account
        this.accountRepository.deleteById(id);
    }

    
}
