package com.devsu.hackerearth.backend.account.exception;

public class CustomExceptions extends RuntimeException{

    public CustomExceptions(String message) {
        super(message);
    }
    
}

