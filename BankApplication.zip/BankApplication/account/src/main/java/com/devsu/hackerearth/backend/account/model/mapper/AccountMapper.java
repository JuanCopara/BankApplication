package com.devsu.hackerearth.backend.account.model.mapper;

import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.dto.AccountDto;
import com.devsu.hackerearth.backend.account.model.dto.PartialAccountDto;

public class AccountMapper {

    public static AccountDto toAccountDto(Account account) {
        return new AccountDto(account.getId(), account.getNumber(), account.getType(), account.getInitialAmount(),
                account.getIsActive(), account.getClientId());
    }

    public static Account toAccount(AccountDto accountDto) {
        Account account = new Account();
        account.setNumber(accountDto.getNumber());
        account.setType(accountDto.getType());
        account.setInitialAmount(accountDto.getInitialAmount());
        account.setIsActive(accountDto.isActive());
        account.setClientId(accountDto.getClientId());
        return account;
    }

    public static Account updateAccount(Account accountEntity, AccountDto accountDto) {
        accountEntity.setNumber(accountDto.getNumber());
        accountEntity.setType(accountDto.getType());
        accountEntity.setInitialAmount(accountDto.getInitialAmount());
        accountEntity.setIsActive(accountDto.isActive());
        accountEntity.setClientId(accountDto.getClientId());
        return accountEntity;
    }

    public static Account partialUpdateAccount(Account accountEntity, PartialAccountDto partialAccountDto) {
        accountEntity.setIsActive(partialAccountDto.isActive());
        return accountEntity;
    }
}